function leave(){
      return confirm("This will take you to another site,\n are you sure you want to go?")
    }
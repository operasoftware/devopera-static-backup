______________________
README:
~~~~~~~~~~~~~~~~~~~~~~
These files are released under public domain. Do whatever you want with it. The author does not bear any responsibility for any ill-effects. The files are provided for educational purposes.


______________________
HOW TO USE:
~~~~~~~~~~~~~~~~~~~~~~
1. Upload the file (preferebly in a seperate folder) onto your server. The server must have support for PHP5.
2. Once uploaded, access main.htm using your web browser. The browser must have support for application cache and web storage.
3. Type something into the text box. After a few seconds you will notice a the message you typed appearing below on the page as well.
4. The message typed into the text box should still remain there on page reload.
5. However, if you close the tab or window, then the text box will be blank then next time you open the page.
6. If your browser supports it, then goto 'File->Work Offline'. You will see a message on the bottom of the page letting you know you are in offline mode. 
7. Also, while in offline mode, the page will not let you submit the information. 
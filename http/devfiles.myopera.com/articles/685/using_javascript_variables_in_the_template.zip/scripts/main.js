opera.io.webserver.addEventListener( '_request', handleRequest, false );

function handleRequest( event )
{
    var response = event.connection.response;
    
    var data =
    {
        name    : 'Template',
        further :
        {
            down    :
            {
                the :
                {
                    hierarchy:  'yes it is!'
                }
            }
        }
    };
    var template = new Markuper( 'templates/tutorial.html', data );
    
    response.write( template.parse().html() );
    response.close();
}
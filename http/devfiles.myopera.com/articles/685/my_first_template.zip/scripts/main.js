opera.io.webserver.addEventListener( '_request', handleRequest, false );

function handleRequest( event )
{
    var response = event.connection.response;
    
    var template = new Markuper( 'templates/tutorial.html' );
    
    response.write( template.html() );
    response.close();
}
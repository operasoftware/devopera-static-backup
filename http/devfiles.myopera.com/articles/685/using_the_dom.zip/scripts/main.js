opera.io.webserver.addEventListener( '_request', handleRequest, false );

function handleRequest( event )
{
    var response = event.connection.response;
    
    var data =
    {
        name    : 'Template'
    };
    var template = new Markuper( 'templates/tutorial.html', data );
    
    // XPath
    //var span = template.xpath( "//div[@id='div1']/span[1]" )[0];
    // CSS Selector
    var span = template.select( "#div1 > span" )[0];
    
    span.parentNode.removeChild( span );
    
    response.write( template.parse().html() );
    response.close();
}
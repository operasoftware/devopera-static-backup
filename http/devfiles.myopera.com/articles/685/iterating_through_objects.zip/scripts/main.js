opera.io.webserver.addEventListener( '_request', handleRequest, false );

function handleRequest( event )
{
    var response = event.connection.response;
    
    var data =
    {
        name    : 'Template',
        cities  :
        [
            {city: 'Lisbon', temperature: 20},
            {city: 'Oslo'  , temperature: -2}
        ]
    };
    
    var template = new Markuper( 'templates/tutorial.html', data );
    
    response.write( template.parse().html() );
    response.close();
}
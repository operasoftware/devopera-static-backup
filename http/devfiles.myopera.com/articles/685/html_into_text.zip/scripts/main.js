opera.io.webserver.addEventListener( '_request', handleRequest, false );

function handleRequest( event )
{
    var response = event.connection.response;
    
    var data =
    {
        name    : 'Template',
    };
    var template = new Markuper( 'templates/tutorial.html', data );
    
    template.registerDataAttribute( 'show-html', function( node, data, key )
    {
        if( key == 'true' )
        {
            node.textContent = node.innerHTML;
        }
    });
    
    response.write( template.parse().html() );
    response.close();
}
﻿function leave(){
      return confirm("Ezzel átugrasz egy másik oldalra,\n biztos, hogy ezt akarod?")
    }
/**
 * � Copyright 2009 Opera Software ASA. All rights reserved.
 *
 * This file contains Original Code and/or Contributions to the Original 
 * Code as defined in the Opera Web Applications License (the �License�). 
 * You may not use this file except in compliance with the License. Please 
 * obtain a copy of the License at http://www.opera.com/license/owal/
 * and read it before using this file. 
 *
 * The Original Code and all Contributions to the Original Code distributed 
 * under the License are distributed on an �AS IS� basis, WITHOUT WARRANTY 
 * OF ANY KIND, EITHER EXPRESS OR IMPLIED, AND OPERA HEREBY DISCLAIMS ALL 
 * SUCH WARRANTIES, INCLUDING WITHOUT LIMITATION, ANY WARRANTIES OF 
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NON-INFRINGEMENT. 
 *
 * Please see the License for the specific language governing rights and 
 * limitations under the License.
 */

window.addEventListener("DOMContentLoaded", function(event)
{
	// Test is the resolution is less than 800x600
	if(screen.availHeight + screen.availWidth < 1400)
	{
		window.resizeTo(screen.availWidth, screen.availHeight);

	  	//In case resolution changes resize the widget.
		widget.addEventListener('resolution', function()
		{
			window.resizeTo(screen.availWidth, screen.availHeight);
	 	}, false);
	}	
	
}, false);

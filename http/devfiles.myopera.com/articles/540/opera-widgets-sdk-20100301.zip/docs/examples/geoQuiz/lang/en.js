/* English */
window.localeStrings = 
{
	'score':'Score:',
	'welcome': 'Welcome',
    'welcomeText':'Test your geographical knowledge by selecting the capital for a given country. You have 12 seconds to choose the right option and only three lives to answer incorrectly. Good Luck.',
    'start':'Start',
    'question':'What is the capital of ',
	'highScore':'High Score',
	'topScore':'Congratulations! Please enter your name into the hall of fame and try again.',
	'inTop5' : "Please enter your name into the hall of fame and try again. Try scoring even better this time.",
	'zeroScore' : "Go and buy a globe first.",
	'notinTop5' : "Try again. You may have better luck this time.",
	'tryagain':'Try Again'
}

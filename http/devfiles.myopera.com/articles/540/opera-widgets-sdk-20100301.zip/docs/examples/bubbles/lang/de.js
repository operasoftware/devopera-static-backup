/* German */
window.localeStrings = ( 
     INSTRUCTIONS         : "Entfernen Sie alle Blasen, indem Sie auf gleichfarbige Nachbarn klicken. Je mehr Blasen Sie mit einem Klick entfernen, desto mehr Punkte.", 
     OK                   : "Start", 
     SCORE                : "Resultat:", 
     HI_SCORE             : "Bestresultat:", 
     INSTRUCTIONS_Loosing : "Leider konnten Sie nicht alle Blasen entfernen. Versuchen Sie es nochmals!" 
     INSTRUCTIONS_Winning : "Gratulation, Sie haben alle Blasen vom Bildschirm entfernt. Versuchen Sie nun Ihr Ergebnis zu verbessern." 
     RESTART              : "Neustart", 
);

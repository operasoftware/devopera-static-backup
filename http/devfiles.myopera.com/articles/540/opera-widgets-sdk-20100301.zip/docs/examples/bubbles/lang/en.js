/* English */
window.localeStrings = {
    INSTRUCTIONS           : "Make all bubbles vanish by clicking on the ones that have same coloured neighbours. The more bubbles you remove by one click,the more points you win.",
    OK                     : "Start",
    SCORE                  : "Score:",
    HI_SCORE               : "Top:",
    INSTRUCTIONS_Loosing   : "You did not manage to remove all bubbles. Try again!",
    INSTRUCTIONS_Winning   : "You cleared off all bubbles from the screen. Now try if you can score even higher.",
    RESTART                : "Restart",
};

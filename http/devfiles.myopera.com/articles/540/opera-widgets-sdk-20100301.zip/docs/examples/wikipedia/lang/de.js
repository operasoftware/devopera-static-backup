/**
 * � Copyright 2009 Opera Software ASA. All rights reserved.
 *
 * This file contains Original Code and/or Contributions to the Original 
 * Code as defined in the Opera Web Applications License (the �License�). 
 * You may not use this file except in compliance with the License. Please 
 * obtain a copy of the License at http://www.opera.com/license/owal/
 * and read it before using this file. 
 *
 * The Original Code and all Contributions to the Original Code distributed 
 * under the License are distributed on an �AS IS� basis, WITHOUT WARRANTY 
 * OF ANY KIND, EITHER EXPRESS OR IMPLIED, AND OPERA HEREBY DISCLAIMS ALL 
 * SUCH WARRANTIES, INCLUDING WITHOUT LIMITATION, ANY WARRANTIES OF 
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NON-INFRINGEMENT. 
 *
 * Please see the License for the specific language governing rights and 
 * limitations under the License.
 */
 
/* German */
window.localeStrings =
{
	'WIDGET_TITLE'      : 'Wikipedia',

	'first start'       : 'Willkommen. Benutzen Sie diese Startseite des Wikipedia Widgets um neue und nahegelegene Artikel zu suchen oder zuletzt besuchte Artikel zu sehen.',

	'random article'    : 'Zuf�lliger Artikel',
	'previous searches' : 'Zuletzt besuchte Artikel',
	'language select'   : 'Wiki Sprache:',  //  to select the language

    'search'            : 'Suchen', //  label of the search button
    'searching'         : 'Wird gesucht...',
    'loading'           : 'Wird geladen...',
    'toc'               : 'Inhaltsverzeichnis',
    'search results'    : 'Suchresultate',

    'error'             : 'Verbindungsfehler.',
    'retry'             : 'Bitte erneut versuchen.',

    'signature'         : 'Aus Wikipedia, der freien Enzyklop�die.',

    "Receiving data": "Daten werden empfangen...",
    "Requesting data": "Daten werden angefordert...",
    "Offline": "Offline",
    "Network Error": "Netzwerk Fehler",
    "Error message #1": "Es konnte keine Internetverbindung hergestellt werden, bitte pr�fen Sie ihre Datenverbindung.",
    "Error message #2": "Keine Antwort empfangen, bitte versuchen Sie es sp�ter nochmals.",
    "OK": "OK",
    "Cancel": "Abbrechen",
    "Retry": "Nochmals versuchen",
    "Yes": "Ja",
    "No": "Nein",

    "English": "English",
    "Spanish": "Espa�ol",
    "Italian": "Italiano",
    "German": "Deutsch",
    "Select a language": "Sprache w�hlen",

    "Pages Close By"    : "Nahe Seiten",
    "location"          : "Position",
    "top pages"         : "Top Seiten",
    "old"               : ": Alte Position",

    '__stringId__'      : 'locale string'  // and this is a dummy string to illustrate the format of this file, don't bother localizing that
}
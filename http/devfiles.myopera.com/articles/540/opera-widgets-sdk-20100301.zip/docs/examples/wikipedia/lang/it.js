/**
 * � Copyright 2009 Opera Software ASA. All rights reserved.
 *
 * This file contains Original Code and/or Contributions to the Original 
 * Code as defined in the Opera Web Applications License (the �License�). 
 * You may not use this file except in compliance with the License. Please 
 * obtain a copy of the License at http://www.opera.com/license/owal/
 * and read it before using this file. 
 *
 * The Original Code and all Contributions to the Original Code distributed 
 * under the License are distributed on an �AS IS� basis, WITHOUT WARRANTY 
 * OF ANY KIND, EITHER EXPRESS OR IMPLIED, AND OPERA HEREBY DISCLAIMS ALL 
 * SUCH WARRANTIES, INCLUDING WITHOUT LIMITATION, ANY WARRANTIES OF 
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NON-INFRINGEMENT. 
 *
 * Please see the License for the specific language governing rights and 
 * limitations under the License.
 */
 
/* Italian */
window.localeStrings =
{
	'WIDGET_TITLE'      : 'Wikipedia',

	'first start'       : 'Benvenuti a Wikipedia Widget. Usa questa home page per le tue ricerche o consultare lo storico.',

	'random article'    : 'Articolo a caso',
	'previous searches' : 'Pagine recenti',
	'language select'   : 'Seleziona il linguaggio per il Wiki:',  //  to select the language

    'search'            : 'Ricerca', //  label of the search button
    'searching'         : 'Ricerca...',
    'loading'           : 'Caricamento...',
    'toc'               : 'TOC',
    'search results'    : 'Resultati ricerca',

    'error'             : 'Errore di connessione.',
    'retry'             : 'Riprova.',

    'signature'         : 'Da Wikipedia, l\'enciclopedia libera.',

    "Receiving data": "Ricevimento dati",
    "Requesting data": "Richiesta dati",
    "Offline": "Offline",
    "Network Error": "Errore di rete",
    "Error message #1": "Ci sono problemi per accedere a Internet. Per favore controlla la tua connessione.",
    "Error message #2": "Nessuna risposta, per favore riprova pi� tardi.",
    "OK": "OK",
    "Cancel": "Cancella",
    "Retry": "Riprova",
    "Yes": "Si",
    "No": "No",

    "English": "English",
    "Spanish": "Espa�ol",
    "Italian": "Italiano",
    "German": "Deutsch",
    "Select a language": "Selezione di lingua",

    "Pages Close By"    : "Pagine Cercas",
    "location"          : "Localit�",
    "top pages"         : "Pagine Pi� Importante",
    "old"               : ": Locaci�n Vecchio",

    '__stringId__'      : 'locale string'  // and this is a dummy string to illustrate the format of this file, don't bother localizing that
}
/**
 * � Copyright 2009 Opera Software ASA. All rights reserved.
 *
 * This file contains Original Code and/or Contributions to the Original 
 * Code as defined in the Opera Web Applications License (the �License�). 
 * You may not use this file except in compliance with the License. Please 
 * obtain a copy of the License at http://www.opera.com/license/owal/
 * and read it before using this file. 
 *
 * The Original Code and all Contributions to the Original Code distributed 
 * under the License are distributed on an �AS IS� basis, WITHOUT WARRANTY 
 * OF ANY KIND, EITHER EXPRESS OR IMPLIED, AND OPERA HEREBY DISCLAIMS ALL 
 * SUCH WARRANTIES, INCLUDING WITHOUT LIMITATION, ANY WARRANTIES OF 
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NON-INFRINGEMENT. 
 *
 * Please see the License for the specific language governing rights and 
 * limitations under the License.
 */
 
/* Spanish */
window.localeStrings =
{
	'WIDGET_TITLE'      : 'Wikipedia',

	'first start'       : 'Bienvenidos a los Widgets de Wikipedia. Use la pagina de inicio para comenzar su b�squeda, leer art�culos de la circundante o art�culos reciente.',

	'random article'    : 'Art�culos Indiscriminados',
	'previous searches' : 'Paginas Recientes',
	'language select'   : 'Seleccione lenguaje Wiki:',  // to select the language

    'search'            : 'B�squeda', //  label of the search button
    'searching'         : 'Buscando...',
    'loading'           : 'Cargando...',
    'toc'               : 'TOC',
    'search results'    : 'Resultado de la B�squeda',

    'error'             : 'Error de conexi�n.',
    'retry'             : 'Intente de nuevo por favor.',

    'signature'         : 'Desde Wikipedia, la enciclopedia gratis.',

    "Receiving data": "Recibiendo informaci�n",
    "Requesting data": "Solicitando informaci�n",
    "Offline": "Fuera de linea",
    "Network Error": "Error de Red",
    "Error message #1": "Hubo un problema para acceder al Internet. Por favor revise su conexi�n.",
    "Error message #2": "No hay respuesta, por favor trate mas tarde.",
    "OK": "OK",
    "Cancel": "Cancelar",
    "Retry": "Reintentar",
    "Yes": "Si",
    "No": "No",

    "English": "English",
    "Spanish": "Espa�ol",
    "Italian": "Italiano",
    "German": "Deutsch",
    "Select a language": "Selecci�n de idioma",

    "Pages Close By"    : "Paginas Cercas",
    "location"          : "Locaci�n",
    "top pages"         : "Paginas Mas Importantes",
    "old"               : ": Locaci�n Viejo",

    '__stringId__'      : 'indicativo local'  // and this is a dummy string to illustrate the format of this file, don't bother localizing that
}
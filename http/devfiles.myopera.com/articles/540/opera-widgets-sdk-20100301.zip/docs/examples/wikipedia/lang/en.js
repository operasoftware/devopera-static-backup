/**
 * � Copyright 2009 Opera Software ASA. All rights reserved.
 *
 * This file contains Original Code and/or Contributions to the Original 
 * Code as defined in the Opera Web Applications License (the �License�). 
 * You may not use this file except in compliance with the License. Please 
 * obtain a copy of the License at http://www.opera.com/license/owal/
 * and read it before using this file. 
 *
 * The Original Code and all Contributions to the Original Code distributed 
 * under the License are distributed on an �AS IS� basis, WITHOUT WARRANTY 
 * OF ANY KIND, EITHER EXPRESS OR IMPLIED, AND OPERA HEREBY DISCLAIMS ALL 
 * SUCH WARRANTIES, INCLUDING WITHOUT LIMITATION, ANY WARRANTIES OF 
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NON-INFRINGEMENT. 
 *
 * Please see the License for the specific language governing rights and 
 * limitations under the License.
 */
 
/* English */
window.localeStrings =
{
	'WIDGET_TITLE'      : 'Wikipedia',

	'first start'       : 'Welcome to the Wikipedia Widget. Use this home page to start your search, find pages close by and visit your recent history.',
    
	'random article'    : 'Random Article',
	'previous searches' : 'Recent Pages',
	'language select'   : 'Select Wiki language:',  //  to select the language

    'search'            : 'Search', //  label of the search button
    'searching'         : 'Searching...',
    'loading'           : 'Loading...',
    'toc'               : 'TOC',
    'search results'    : 'Search Results',

    'error'             : 'Connection error.',
    'retry'             : 'Please retry.',

    'signature'         : 'From Wikipedia, the free encyclopedia.',

    "Receiving data": "Receiving data",
    "Requesting data": "Requesting data",
    "Offline": "Offline",
    "Network Error": "Network Error",
    "Error message #1": "There was a problem accessing the Internet. Please check your connection.",
    "Error message #2": "Not getting a response, please try again later.",
    "OK": "OK",
    "Cancel": "Cancel",
    "Retry": "Retry",
    "Yes": "Yes",
    "No": "No",
    
    "English": "English",
    "Spanish": "Espa�ol",
    "Italian": "Italiano",
    "German": "Deutsch",
    "Select a language": "Select a language",

    "Pages Close By"    : "Pages Close By",
    "location"          : "Location",
    "top pages"         : "Top Pages",
    "old"               : "Old Location",
    "powered by"        : "Powered by:",

    '__stringId__'      : 'locale string'  // and this is a dummy string to illustrate the format of this file, don't bother localizing that
    
    
}
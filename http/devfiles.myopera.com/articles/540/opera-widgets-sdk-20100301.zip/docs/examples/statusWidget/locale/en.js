/**
 * � Copyright 2009 Opera Software ASA. All rights reserved.
 *
 * This file contains Original Code and/or Contributions to the Original 
 * Code as defined in the Opera Web Applications License (the �License�). 
 * You may not use this file except in compliance with the License. Please 
 * obtain a copy of the License at http://www.opera.com/license/owal/
 * and read it before using this file. 
 *
 * The Original Code and all Contributions to the Original Code distributed 
 * under the License are distributed on an �AS IS� basis, WITHOUT WARRANTY 
 * OF ANY KIND, EITHER EXPRESS OR IMPLIED, AND OPERA HEREBY DISCLAIMS ALL 
 * SUCH WARRANTIES, INCLUDING WITHOUT LIMITATION, ANY WARRANTIES OF 
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NON-INFRINGEMENT. 
 *
 * Please see the License for the specific language governing rights and 
 * limitations under the License.
 */
 
/* English */
window.localeStrings =
{
    'Settings'      	: 'Settings',
    'Ping.fm'			: 'Ping.fm',
    'Reset'				: 'Reset',
    'Publish'			: 'Publish',
    'welcome_text'		: 'Welcome to the status widget. You need to copy your Ping.fm credentials to post through your profile.',	
    'register_here' 	: 'Register here',
    'open_link'			: 'Open link',
    'below_log'			: 'below and log in.',
    'copy_key'			: 'Copy key.',
    'use_tap_hold'		: 'Use tap-hold to copy.',	
    'close'				: 'Close',
    'browser'			: 'browser.',	
    'paste_key_here'	: 'Paste key here (tap-hold)',
    'into_text_field'	: 'into text field below.',	
    'From'				: 'From:',
	'paste_key'			: 'paste key',    
    'done'				: 'Done',
    'validate_text' 	: 'Please wait while we are validating your credentials against the Ping.fm site.',
    'cancel' 			: 'Cancel',
    'validating' 		: 'Validating...',
    'pingfm_key'		: 'Ping.fm key:',
    'update'			: 'Update',
    'pingfm_pushing'	: 'Ping.fm pushing to:',
    'Published'     	: 'Published',
    'could_not_publish' : 'Could not publish.',
    'Publishing'		: 'Publishing...',
    'Send' 				: 'Send',
    'Validating1' 		: 'Validating',
    'add_network'   	: 'Add network',
    'Failure'			: 'Failure',
    'Success'			: 'Success',
	'not_endorsed'		: 'This product uses the Ping.fm API but is not endorsed or certified by Ping.fm.',
    
    '__stringId__'      : 'locale string'  // and this is a dummy string to illustrate the format of this file, don't bother localizing that
    
}
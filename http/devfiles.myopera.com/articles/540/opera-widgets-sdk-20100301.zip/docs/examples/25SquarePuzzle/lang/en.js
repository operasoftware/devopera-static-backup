/* English */
window.localeStrings = 
{
	'title' : '25 Square Puzzle',
    'startText' : 'Try to fill all 25 squares with as few clicks as possible. Selecting one square will invert it and its neighbours above, below, left and right.',
    'start':'Start',
	'Clicks' : 'Clicks: ',
    'winmsg' : 'Congratulations!',
	'winText1' : 'You have used only ',
    'winText2' : ' clicks to fill all squares. Can you beat that?',  	
	'restart' : 'Restart',
	'close':'Close'
}

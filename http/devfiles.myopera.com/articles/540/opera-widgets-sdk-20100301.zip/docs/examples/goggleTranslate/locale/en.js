/* English */
window.localeStrings = 
{
	'translate'   : 'Translate',
	'defaultText' :'Enter text ',
	'retry'       :'Retry',
	'Error'       :'Error:',
	'errorMsg'    :' Cannot access Google Translate. Please check your Internet connection and try again.',
	'cancel'      :'Cancel',
	'translating' :'translating...'
}

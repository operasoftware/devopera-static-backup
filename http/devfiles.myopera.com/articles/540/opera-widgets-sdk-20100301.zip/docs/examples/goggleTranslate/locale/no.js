/* norwegian */
window.localeStrings = 
{
   'translate'    :'oversette',
   'defaultText'  :'Skriv inn tekst ',
   'retry'        :'Prøv',
   'Error'        :'Feil:',
   'errorMsg'     :'Får ikke tilgang til Google Translate. Kontroller Internett-tilkoblingen din og prøv igjen.',
   'cancel'       :'Avbryt'
}

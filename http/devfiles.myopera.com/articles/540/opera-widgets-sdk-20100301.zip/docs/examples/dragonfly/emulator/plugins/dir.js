/*
 This variable references all plugin folders.
 We need this since we cannot get a directory listing yet in widgets
*/
var g_plugins = [
    'network_security',
    'xhr_throttler'
];
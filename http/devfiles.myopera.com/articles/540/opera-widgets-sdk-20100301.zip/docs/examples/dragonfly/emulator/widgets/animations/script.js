window.addEventListener("load", function(){
    if(screen.availWidth < 600 || screen.availHeight < 600)
    {
        window.resizeTo(screen.availWidth, screen.availHeight);
    }
    if(screen.availWidth < 400 || screen.availHeight < 400)
    {
        var columnOne = document.getElementById('columnOne');
        var columnTwo = document.getElementById('columnTwo');

        columnOne.animShow = columnOne.createAnimation();
        columnOne.animShow.addAnimation("left", "-100%", "0%");

        columnOne.animHide = columnOne.createAnimation();
        columnOne.animHide.addAnimation("left", "0%", "-100%");

        columnTwo.animShow = columnTwo.createAnimation();
        columnTwo.animShow.addAnimation("left", "100%", "0%");

        columnTwo.animHide = columnTwo.createAnimation();
        columnTwo.animHide.addAnimation("left", "0%", "100%");

        columnOne.addEventListener("click", function(){
            columnOne.animHide.run();
            columnTwo.animShow.run();
        }, false);

        columnTwo.addEventListener("click", function(){
        columnOne.animShow.run();
        columnTwo.animHide.run();
        }, false);
    }
}, false);
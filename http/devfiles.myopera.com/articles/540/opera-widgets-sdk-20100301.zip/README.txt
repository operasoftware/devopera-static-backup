Opera Widgets Software Development Kit (SDK)

This package is intended for widget developers and making the process of 
developing widgets easier.

See the licenses/ directory for information on the license for this package.

Content

docs/ - Documentation, examples and specifications
lib/  - JavaScript libraries for making development easier
util/ - Various utilities, such as the Widget 
Emulator.

NOTE: all articles on Widget development have been moved out of this zip file and now can be found on http://dev.opera.com/articles/view/opera-widgets-sdk/


Changelog:

Version 0.5

o New articles added about the Desktop Widget runtime and Widget control buttons. 
o Rewrote Opera Widgets Style Guide.
o Updated desktop and mobile screenshots to reflect latest releases on desktop and mobile.
o Removed articles and S60, Windows Mobile builds out of the zip package.
o Various other edits.

Version 0.4

o Updated Opera Widgets spec to include the feature element and the new security model.
o Updated the security model article to reflect the model in Opera 10, and how to make widgets backwards and forwards compatible.
o Added complete widgets as widget examples.
o Documented the widgetfile element and the resolution event properly.
o Various bug fixes in the emulator.
o Various text and link fixes.

Version 0.3

o Added an article on different Widget managers
o Added a beta of the Windows Mobile 9.7 Widget manager. Note that the 
browser must be installed first.
o Added updated version of the S60 Widget manager.
o Added an article on remote debugging of widgets.
o Major update of the emulator, various bugfixes:
  o The emulator now requires the attribute network to be present on the 
widget element with the value "public" to be able to connect to servers. This 
is in preparation for the new security model in Opera 10. Please update 
your widgets. Adding this attribute will not break widgets for earlier versions
  o Support for multiple widgets: Add unpacked widgets to the widgets 
directory of the emulator and add the names of the directories to the 
dir.js file to register them in the emulator.
  o Initial support for plugins.
  o New design
versions of Opera.
o Added this readme.
o Various text and link fixes.

Version 0.2

o Added the S60 Widget Manager.
o Added a fast track guide to the SDK.
o Added an article on optimization of graphics for widgets.
o Added an article on using Opera Dragonfly with widgets and the 
emulator.

Version 0.1

Initial version of the SDK.

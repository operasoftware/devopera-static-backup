/**
 * List the folder name of each widget
 * in this directory that you want to
 * appear in the emulator.
 */

var g_widgets = [
  'weather',
  'bubbles'
];

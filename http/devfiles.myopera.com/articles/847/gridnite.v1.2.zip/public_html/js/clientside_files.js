function switch_page(page) {
	document.location = uri_base + '?filename='+encodeURIComponent(page);
};

function current_page(page) {
		return current_page__;
};

$(document).ready(function() {
	$('<span>File: <strong id="filename"><a href=# onClick="files_switch(); return false;">' +current_page()+ '</a></strong></span> | ' +
	  '<a href=# onClick="files_new(); return false;">New spreadsheet</a> ' +
	  '<a href=# onClick="files_switch(); return false;">Switch to another file</a> ' +
	  //<!--a href=#>Download as JSON</a> <a href=#>Upload JSON</a> <a href=#>Download as Excel XML</a-->'
	  '').appendTo('.menu_items');
});

function files_new() {
	function cb(v,m,f) {
		an = m.children('#alertName');
		if(!an.attr('value')){
			an.css("border","solid #ff0000 1px");
			return false;
		};
		var fn = an.attr('value');
		if(!fn.match(/\./)) {
			fn += '.json';
		};
		switch_page(fn);
		return true;
	};
	$.prompt(
		'New file name:<br><input type="text" id="alertName" value="">',
		{
			submit: cb,
			buttons: { Ok:true },
			persistent: false
		}
	);
	$('#alertName').focus();
};

function files_switch() {
	$.getJSON(uri_base + 'list_files?json=1', function(files_list) {
		files_list_html = '';
		for(var i=0; i<files_list.length; i++) {
			files_list_html += '<a href=# onClick="switch_page(this.text); return false;">' + files_list[i] + '</a>';
		};

		$.prompt(
			'Open file:<br><div class=file_list>' + files_list_html + '</div>',
			{
				buttons: { Ok: true, Cancel:false },
				persistent: false
			}
		);
	});
};